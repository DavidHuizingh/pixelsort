from pixelsort.main import pixelsort
NAME = "pixelsort"
