from pixelsort import pixelsort
from PIL import Image
from pathlib import Path
from time import sleep

image = "Ollie.jpg"
mask = "Head circle_Inverted.jpg"
image_out = "Ollie_Sorted.jpg"

p = Path()

img_path = p / image
image_in = str(img_path.absolute())

mask_path = p / mask
mask_in = str(mask_path.absolute())

out_path = p / image_out
image_out = str(out_path.absolute())

image_in_PIL = Image.open(image_in)
mask_PIL = Image.open(mask_in)


#pil_in = Image(image_p_in)

sort_settings = {     
    "interval_image" : None,                    # None Default
    "randomness": 0,                            # 0 Default
    "clength": 250,                              # 50 Default
    "sorting_function": "intensity",            # "lightness" Default               
    "interval_function": "random",           # "threshold" Default
    "lower_threshold": 0.4,                    # .25 Default
    "upper_threshold": 0.7,                     # .8 Default
    "angle": 270                                  # 0 Default
    }
#img_sorted = pixelsort(image_in_PIL)

img_sorted = pixelsort(
    image_in_PIL,
    mask_image=mask_PIL,
    interval_image=sort_settings["interval_image"],
    randomness=sort_settings["randomness"],
    clength=sort_settings["clength"],
    sorting_function=sort_settings["sorting_function"],
    interval_function=sort_settings["interval_function"],
    lower_threshold=sort_settings["lower_threshold"],
    upper_threshold=sort_settings["upper_threshold"],
    angle=0
    )

img_rgb = img_sorted.convert("RGB")
img_rgb.save(image_out)
img_rgb.show()
print(f"Saved image path: {image_out}")